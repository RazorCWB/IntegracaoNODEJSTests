const {MongoClient} = require('mongodb');
const request = require("supertest");
const app = require("../src/entrypoint/express/startExpress");


describe("GET /acao", () => {
    let conexao;
    let banco;
  
    beforeAll(async () => {
      conexao = await MongoClient.connect("mongodb+srv://devDB:CMGXj4AT1kyEpQ7J@clusternodeaula.w5kwg.gcp.mongodb.net/ClusterNODEAula?retryWrites=true&w=majority", {
        useNewUrlParser: true,
      });
      banco = await conexao.db("TrabalhoNODEAPI");
    });
    afterAll(async () => {
      await conexao.close();
      await banco.close();
    });

  test("Deverá listar todas ações", () => {
    return request(app)
      .get("/acao")
      .expect(200);
  });
});

describe("GET /fundo", () => {
  let conexao;
  let banco;

  beforeAll(async () => {
    conexao = await MongoClient.connect("mongodb+srv://devDB:CMGXj4AT1kyEpQ7J@clusternodeaula.w5kwg.gcp.mongodb.net/ClusterNODEAula?retryWrites=true&w=majority", {
      useNewUrlParser: true,
    });
    banco = await conexao.db("TrabalhoNODEAPI");
  });

  afterAll(async () => {
    await conexao.close();
    await banco.close();
  });

test("Deverá listar todos os fundos", () => {
  return request(app)
    .get("/fundo")
    .expect(200);
});
});


describe("GET /acao/{id}", () =>{
  let conexao;
  let banco;

  beforeAll(async () => {
    conexao = await MongoClient.connect("mongodb+srv://devDB:CMGXj4AT1kyEpQ7J@clusternodeaula.w5kwg.gcp.mongodb.net/ClusterNODEAula?retryWrites=true&w=majority", {
      useNewUrlParser: true,
    });
    banco = await conexao.db("TrabalhoNODEAPI");
  });
  afterAll(async () => {
    await conexao.close();
    await banco.close();
  });

  test("Deverá encontrar a ação com o id 5f6905d51fad410c666b75f5", () => {
      return request(app)
      .get("/acao/5f6905d51fad410c666b75f5")
      .expect(200);
  });
});

describe("POST /acao", () =>{
  let conexao;
  let banco;

  beforeAll(async () => {
    conexao = await MongoClient.connect("mongodb+srv://devDB:CMGXj4AT1kyEpQ7J@clusternodeaula.w5kwg.gcp.mongodb.net/ClusterNODEAula?retryWrites=true&w=majority", {
      useNewUrlParser: true,
    });
    banco = await conexao.db("TrabalhoNODEAPI");
  });
  afterAll(async () => {
    await conexao.close();
    await banco.close();
  });

  test("Deverá retornar 200 e checar se foi criado com sucesso", () => {
      return request(app)
      .post("/acao")
      .send({ name:"AÇÃO NOVA", localidade:"PINDAMONHANGABA" })
      .expect(200)
      .then(() => {
        return request(app)
        .get("/fundo")
        .query({ name:"AÇÃO NOVA"})
        .expect(200)
      });
  });
});

describe("GET /fundo/{id}", () =>{
    let conexao;
    let banco;
  
    beforeAll(async () => {
      conexao = await MongoClient.connect("mongodb+srv://devDB:CMGXj4AT1kyEpQ7J@clusternodeaula.w5kwg.gcp.mongodb.net/ClusterNODEAula?retryWrites=true&w=majority", {
        useNewUrlParser: true,
      });
      banco = await conexao.db("TrabalhoNODEAPI");
    });
    afterAll(async () => {
      await conexao.close();
      await banco.close();
    });

    test("Deverá encontrar o fundo com o id 5f6905d51fad410c666b75f5", () => {
        return request(app)
        .get("/fundo/5f6905d51fad410c666b75f5")
        .expect(200);
    });
});

describe("PUT /acao/{id}", () => {
  let conexao;
  let banco;

  beforeAll(async () => {
    conexao = await MongoClient.connect("mongodb+srv://devDB:CMGXj4AT1kyEpQ7J@clusternodeaula.w5kwg.gcp.mongodb.net/ClusterNODEAula?retryWrites=true&w=majority", {
      useNewUrlParser: true,
    });
    banco = await conexao.db("TrabalhoNODEAPI");
  });
  afterAll(async () => {
    await conexao.close();
    await banco.close();
  });

  it("Deverá retornar 200 e checar se foi atualizado", () => {
    return request(app)
      .put("/acao/5fbd677997a3e4161485e061")
      .send({ name:"AÇÃO ATUALIZADA2"})
      .expect(200)
      .then(() => {
        return request(app)
        .get("/acao")
        .query({ name:"AÇÃO ATUALIZADA2" })
        .expect(200)
      });
  });
});

describe("POST /fundo", () =>{
    let conexao;
    let banco;
  
    beforeAll(async () => {
      conexao = await MongoClient.connect("mongodb+srv://devDB:CMGXj4AT1kyEpQ7J@clusternodeaula.w5kwg.gcp.mongodb.net/ClusterNODEAula?retryWrites=true&w=majority", {
        useNewUrlParser: true,
      });
      banco = await conexao.db("TrabalhoNODEAPI");
    });
    afterAll(async () => {
      await conexao.close();
      await banco.close();
    });

    test("Deverá retornar 200 e checar se foi criado com sucesso", () => {
        return request(app)
        .post("/fundo")
        .send({ name:"JESTTTT", jobTitle:"JESTTTTTTT" })
        .expect(200)
        .then(() => {
          return request(app)
          .get("/fundo")
          .query({ name:"JESTTTT" })
          .expect(200)
        });
    });
});

describe("PUT /fundo/{id}", () => {
    let conexao;
    let banco;
  
    beforeAll(async () => {
      conexao = await MongoClient.connect("mongodb+srv://devDB:CMGXj4AT1kyEpQ7J@clusternodeaula.w5kwg.gcp.mongodb.net/ClusterNODEAula?retryWrites=true&w=majority", {
        useNewUrlParser: true,
      });
      banco = await conexao.db("TrabalhoNODEAPI");
    });
    afterAll(async () => {
      await conexao.close();
      await banco.close();
    });

    it("Deverá retornar 200 e checar se foi atualizado", () => {
      return request(app)
        .put("/fundo/5f6905d51fad410c666b75f5")
        .send({ name:"FUNDO NOVO", volatilidade:"67" })
        .expect(200)
        .then(() => {
          return request(app)
          .get("/fundo")
          .query({ name:"FUNDO NOVO" })
          .expect(200)
        });
    });
  });

  describe("Delete /acao/{id}", () => {
    let conexao;
    let banco;
  
    beforeAll(async () => {
      conexao = await MongoClient.connect("mongodb+srv://devDB:CMGXj4AT1kyEpQ7J@clusternodeaula.w5kwg.gcp.mongodb.net/ClusterNODEAula?retryWrites=true&w=majority", {
        useNewUrlParser: true,
      });
      banco = await conexao.db("TrabalhoNODEAPI");
    });
    afterAll(async () => {
      await conexao.close();
      await banco.close();
    });

    it("Deverá retornar 200 e checar se foi deletado", () => {
      return request(app)
        .del("/acao/5fbd7d2a7ae2693ac03dd3be")
        .expect(200)
        .then(() => {
          return request(app)
          .del("/acao/5fbd7d2a7ae2693ac03dd3be")
          .expect(200)
        });
    });
  });

  describe("Delete /fundo/{id}", () => {
    let conexao;
    let banco;
  
    beforeAll(async () => {
      conexao = await MongoClient.connect("mongodb+srv://devDB:CMGXj4AT1kyEpQ7J@clusternodeaula.w5kwg.gcp.mongodb.net/ClusterNODEAula?retryWrites=true&w=majority", {
        useNewUrlParser: true,
      });
      banco = await conexao.db("TrabalhoNODEAPI");
    });
    afterAll(async () => {
      await conexao.close();
      await banco.close();
    });

    it("Deverá retornar 200 e checar se foi deletado", () => {
      return request(app)
        .del("/fundo/5fbd7d64cc300e3680c9e6fc")
        .expect(200)
        .then(() => {
          return request(app)
          .del("/fundo/5fbd7d64cc300e3680c9e6fc")
          .expect(200)
        });
    });
  });


