const startExpress = require('./entrypoint/express/startExpress')

startExpress()