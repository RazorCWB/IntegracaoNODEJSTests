class ListUseCase{


    constructor(presenter, repository, collection) {
        this.presenter = presenter
        this.repository = repository
        this.collection = collection
    }


    async findAll(){
        try {
            const allUsers = await this.repository.find(this.collection, {})
            this.presenter.ok(allUsers)
        } catch (fail) {
            console.log('ListUserUseCase.findAll', fail)
        }
    }

    async findById(userId){
        try {
            const user = await this.repository.findById(this.collection, userId)
            this.presenter.ok(user)
        } catch (fail) {
            console.log('ListUserUseCase.findById', fail)
        }
    }

    async findByName(nameToFound){
        try {
            const user = await this.repository.find(this.collection, { name: nameToFound })
            console.log('NOME RECEBIDO: ', nameToFound)
            this.presenter.ok(user)
        } catch (fail) {
            console.log('ListUserUseCase.findByName', fail)
        }
    }

    


}


module.exports = { ListUseCase }