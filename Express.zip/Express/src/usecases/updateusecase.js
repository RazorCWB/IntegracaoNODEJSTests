class UpdateUseCase {


    constructor(presenter, repository, userDTO, collection) {
        this.presenter = presenter
        this.repository = repository
        this.userDTO = userDTO
        this.collection = collection
    }

    execute(userID) {
        this.update(userID)
    }

    async update(userId) {
        try {
            const user = await this.repository.update(this.collection, userId, this.userDTO)
            this.presenter.ok(user)
        } catch (fail) {
            console.log('UpdateUEeCase.update', fail)
        }
    }
}


module.exports = { UpdateUseCase }