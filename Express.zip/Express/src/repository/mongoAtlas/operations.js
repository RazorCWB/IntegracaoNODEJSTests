const { Connection } = require('./connection')

class OperatorsDB extends Connection {

    async save(collection, data) {
        try{
            const { client, db} = await this.getClientMongoDB()
            await db.collection(collection).insertOne(data)
            client.close()
            return data
        } catch (error) {
            console.log('Operations.save', error)
        } 
    }

    async find(collection, query) {
        try {
            const { client, db } = await this.getClientMongoDB()
            const cursor = await db.collection(collection).find(query)
            const allElements = []
            await cursor.forEach(element => allElements.push(element))
            client.close()
            return allElements
        } catch (error) {
            console.log('Operators.find', error)
        }
    }

    async findById(collection, id) {
        try {
            const query = {_id: this.getObjectId(id)}
            const { client, db } = await this.getClientMongoDB()
            const user = await db.collection(collection).findOne(query)
            client.close()
            return user
        } catch (error) {
            console.log('Operators.findById', error)
        }
    }

    async update(collection, id, data) {
        try {
            const query = {_id: this.getObjectId(id)}
            const { client, db } = await this.getClientMongoDB()
            const user = await db.collection(collection).findOneAndReplace(query, data)
            client.close()
            return user
        } catch (error) {
            console.log('Operators.findById', error)
        }
    }

    async delete(collection, id) {
        try {
            const query = {_id: this.getObjectId(id)}
            const { client, db } = await this.getClientMongoDB()
            const user = await db.collection(collection).findOneAndDelete(query)
            client.close()
            return user
        } catch (error) {
            console.log('Operators.findById', error)
        }
    }

    async deleteByName(collection, nameToDelete) {
        try {
            const query = {name: nameToDelete}
            const { client, db } = await this.getClientMongoDB()
            const user = await db.collection(collection).findOneAndDelete(query)
            client.close()
            return user
        } catch (error) {
            console.log('Operators.findById', error)
        }
    }


    

    
    

}

module.exports = { OperatorsDB }